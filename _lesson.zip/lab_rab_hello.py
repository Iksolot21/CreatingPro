print ('hello world')
print ('hello world')
print ('hello world')
print ('hello world')
print ('hello world')
print ('hello world')

#alt+shift+стрелка - копирование строки
name="Юля"
print ("Привет" + name + '!')
print ("Привет", name, '!')
print (f"Привет {name}!")

def print_sum():
    a=1
    b=2
    print(a+b)

print_sum()

