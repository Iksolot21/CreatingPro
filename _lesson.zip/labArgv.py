import sys

if __name__ == '__main__':
    print('Список аргументов:')
    print(sys.argv)
    # начиная с pyhton 3.10
    print(sys.orig_argv)